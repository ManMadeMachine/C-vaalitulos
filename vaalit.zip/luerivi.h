#include <stdio.h>

char * lueRivi(FILE *syote, size_t *pituus);
